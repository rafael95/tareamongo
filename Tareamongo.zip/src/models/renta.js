import mongoose from 'mongoose'
const Schema = mongoose.Schema

const RentSchema = new Schema({
    cedula: String,
    placa: Number,
    diasderenta: Number,
    montoapagar: Number
})
export default mongoose.model('Renta', RentSchema)
