import mongoose from 'mongoose'
const Schema = mongoose.Schema

const CarSchema = new Schema({
    placa: Number,
    capacidad: Number,
    idMarca: Number,
    idEstilo: Number,
    modelo: String,
    color: String,
    cilindrada: String,
    combustible: String,
    transmision: String,
    año: Number,
    listaExtras: Array,
    cantidadpasajeros:Number,
    precioderentapordia:Number,
    estadorentado:String


})
export default mongoose.model('Vehiculo', CarSchema)
