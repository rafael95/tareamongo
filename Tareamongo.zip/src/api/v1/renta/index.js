import Renta from "../../../models/renta";
function CreateRentRoutes (server){

server.route([

    {
        method:"POST",
        path: "/api/v1/createrent",
        handler: function (request,reply){
            const {cedula,placa,diasderenta,montoapagar}= request.payload;
            const renta =new Renta ({
                cedula,placa,diasderenta,montoapagar
            })
            return renta.save();
        }

    }
])

}
export default CreateRentRoutes



