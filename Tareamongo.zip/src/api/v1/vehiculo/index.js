import Vehiculo from "../../../models/vehiculo";
function CreateCarRoutes (server){

server.route([

    {
        method:"POST",
        path: "/api/v1/createcar",
        handler: function (request,reply){
            const {placa,capacidad,idMarca,idEstilo,modelo,color,cilindrada,combustible,transmision,año,listaExtras,
              cantidadpasajeros,precioderentapordia,estadorentado}= request.payload;
            const vehiculo =new Vehiculo ({
              placa,capacidad,idMarca,idEstilo,modelo,color,cilindrada,combustible,transmision,año,listaExtras,
              cantidadpasajeros,precioderentapordia,estadorentado
            })
            return vehiculo.save();
        }

    }
])

}
export default CreateCarRoutes

