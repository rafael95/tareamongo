import Usuario from "../../../models/usuario";
function CreateUserRoutes (server){

server.route([

    {
        method:"POST",
        path: "/api/v1/createuser",
        handler: function (request,reply){
            const {cedula,nombre,correo,celulares}= request.payload;
            const usuario =new Usuario ({
                 cedula,nombre,correo,celulares
            })
            return usuario.save();
        }

    }
])

}
export default CreateUserRoutes

