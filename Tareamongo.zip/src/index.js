'use strict';

import Hapi from 'hapi';
import mongoose from 'mongoose';
import CreateUserRoutes from "./api/v1/usuario";
import CreateRentRoutes from "./api/v1/renta";
import CreateCarRoutes from "./api/v1/vehiculo";
//Connect to mongo instance

mongoose.connect('mongodb+srv://rafael:trini12.@soad-uc3rv.mongodb.net/test?retryWrites=true')
mongoose.connection.once('open', () => {
  console.log('connected to database')
})

// Create a server with a host and port
const server = Hapi.server({
  host: '192.168.43.175',
  port: 4000
});
CreateUserRoutes(server);
CreateCarRoutes(server);
CreateRentRoutes (server)
// Start the server
const start = async function () {

  try {
    await server.start();
  }
  catch (err) {
    console.log(err);
    process.exit(1);
  }

  console.log('Server running at:', server.info.uri);
};

start();
