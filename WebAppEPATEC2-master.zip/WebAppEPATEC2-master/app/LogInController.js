﻿var app = angular.module('app');

app.controller("myIndexCtrl", function ($scope, $http, $timeout) {

    $scope.userEmail;
    $scope.userPassword;


    $scope.printData = function () {

        //    $http.get("http://localhost:57263/app/testjson/phases.json").then(function (response){
        //        $scope.myPhaseData = response.data.PhaseByProject;
        //    });
        console.log("Email: " + $scope.userEmail);
        console.log("Contraseña: " + $scope.userPassword);
        console.log(localStorage.selectedMaterial);

    }
});

