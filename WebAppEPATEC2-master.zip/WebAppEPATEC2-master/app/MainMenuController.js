﻿var app = angular.module('app');


    $scope.ProductsList = [];
    $scope.Prueba;

    $scope.getProducts = function () {
        console.log("getProducts()");
        $http.get("http://localhost:56702/app/testjson/MaterialsFromEpatec.json").then(function (response) {
            $scope.ProductsList = response.data.Material;
        });
    }

    $scope.cartSelected = function () {
        var name = JSON.parse(localStorage.getItem("Pruebas"));
        console.log(name.Name);

    }

    $scope.selectMaterial = function (x) {
        $scope.Prueba = localStorage.setItem("Pruebas", JSON.stringify(x));
        console.log(x.Name);

    }

});

