    $(function () {

        var tableData;

        $.getJSON('Json/tabla.json', function (data) {
            tableData = data.table;

            initializeTable(0);
        });

        function initializeTable() {
            $("#tablaAdministrador").empty();
            //Pintar cabecera
            var rowH = "<thead><tr><th>Firstname</th><th>Lastname</th><th>Email</th><th>Edit</th></tr></thead>"
            $("#tablaAdministrador").append(rowH);
            // Add las filas a las tablas
            jQuery.each(tableData.rows, function (i, row) {
                var rowHTML = "<tr ><td>" +
                    row.Nombre + "</td><td>" +
                    row.Apellidos + "</td><td>" +
                    row.id + 
                    "</td>";
                $("#tablaAdministrador").append(rowHTML);
               // <td><input id="msg" type="text" placeholder="Additional Info"/></td>

            });
        }
    });