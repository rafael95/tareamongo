﻿(function (){
    'use strict';
    angular.module('app').controller('mainCtrl', mainCtrl);
    function mainCtrl() {
        var vm = this;
        vm.food = 'pizza';
        vm.text = "sdfg";
        vm.num1 = 5;
        vm.num2 = 6;
        vm.result;
        vm.suma = function (num1, num2) {
            vm.result = (num1 + num2);
            return  vm.result;
        };
    }

})();